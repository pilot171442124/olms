<?php
define('HOSTNAME', "localhost"); // Your host name
define('DBNAME', "library_db"); //Database Name
define('DBUSER', "root"); //Database User Name
define('DBPWD', ""); //Database User Password
define('SITETITLE', "Online Library Management System"); //SiteTitle for export header
date_default_timezone_set("Asia/Dhaka");
error_reporting(0);
?>